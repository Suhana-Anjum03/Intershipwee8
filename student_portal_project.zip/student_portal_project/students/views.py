from django.shortcuts import redirect, render
from .models import Student

def home(request):
    students = Student.objects.all()
    return render(request,'home.html', {'students': students})

def add_student(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        age = request.POST['age']
        Student.objects.create(name=name, email=email, age=age)
        return redirect('/')
    return render(request, 'add.html')

def delete_student(request, id):
    student = Student.objects.get(id=id)
    student.delete()
    return redirect('/')

def edit_student(request, id):
    student = Student.objects.get(id=id)

    if request.method == 'POST':
        student.name = request.POST['name']
        student.email = request.POST['email']
        student.age = request.POST['age']
        student.save()
        return redirect('/')

    return render(request, 'edit.html', {'student': student})